<?php 


return[
'Admin Dashboard'=>'لوحة تحكم المسؤول',
'Dashboard'=>'لوحة القيادة',
'Assigned Orders'=>'الأوامر المعينة',
'UnAssigned Orders'=>'الطلبات غير المعينة',
'Completed Orders'=>'الطلبات المكتملة',
'Users'=>'المستخدمين',
'Reports'=> 'التقارير',

'Pending Orders'=>'الطلبات المعلقة',
'Delivered Orders'=>'الطلبات المسلمة',
'New Orders'=>'طلبات جديدة',
'Admin'=>'مشرف',
'Orders Graph'=>'أوامر الرسم البياني',
'Yearly Orders'=>'الطلبات السنوية',
'Contact'=>'اتصل',
'Settings'=>'إعدادات',
'Logout'=>'تسجيل خروج',

]



?>