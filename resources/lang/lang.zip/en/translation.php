<?php 


return[
'Admin Dashboard'=>'Admin Dashboard',
'Dashboard'=>'Dashboard',
'Assigned Orders'=>'Assigned Orders',
'UnAssigned Orders'=>'UnAssigned Orders',
'Completed Orders'=>'Completed Orders',
'Users'=>'Users',
'Reports'=> 'Reports',

'Pending Orders'=>'Pending Orders',
'Delivered Orders'=>'Delivered Orders',
'New Orders'=>'New Orders',
'Admin'=>'Admin',
'Orders Graph'=>'Orders Graph',
'Yearly Orders'=>'Yearly Orders',
'Contact'=>'Contact',
'Settings'=>'Settings',
'Logout'=>'Logout',

]



?>